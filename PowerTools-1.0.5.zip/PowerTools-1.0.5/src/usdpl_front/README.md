[![Crates.io](https://img.shields.io/crates/v/usdpl-front?style=flat-square)](https://crates.io/crates/usdpl-front)

# usdpl-front-front

Front-end library to be called from Javascript.
Targets WASM.

In true Javascript tradition, this part of the library does not support error handling.

