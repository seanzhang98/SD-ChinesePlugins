/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function init_usdpl(a: number): void;
export function target_usdpl(a: number): void;
export function version_usdpl(a: number): void;
export function set_value(a: number, b: number, c: number): number;
export function get_value(a: number, b: number): number;
export function call_backend(a: number, b: number, c: number, d: number): number;
export function __wbindgen_export_0(a: number): number;
export function __wbindgen_export_1(a: number, b: number, c: number): number;
export const __wbindgen_export_2: WebAssembly.Table;
export function __wbindgen_export_3(a: number, b: number, c: number): void;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_export_4(a: number, b: number): void;
export function __wbindgen_export_5(a: number): void;
export function __wbindgen_export_6(a: number, b: number, c: number, d: number): void;
