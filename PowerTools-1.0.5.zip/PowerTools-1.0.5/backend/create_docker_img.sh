#!/bin/bash
# build docker container locally (for testing)

docker build -t powertools_backend .
